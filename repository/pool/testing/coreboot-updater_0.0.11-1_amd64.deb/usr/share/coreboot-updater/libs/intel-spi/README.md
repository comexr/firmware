# intel-spi
Library for accessing Intel PCH SPI
