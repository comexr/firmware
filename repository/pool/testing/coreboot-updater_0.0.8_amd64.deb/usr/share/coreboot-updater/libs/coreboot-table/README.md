# coreboot-table

Library for parsing Coreboot table
