# coreboot-fs

Library for parsing Coreboot filesystem
