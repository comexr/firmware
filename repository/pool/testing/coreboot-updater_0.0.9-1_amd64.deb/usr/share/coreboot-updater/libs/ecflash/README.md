# ecflash

Flashing and querying with System76 Embedded Controllers
