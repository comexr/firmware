# intelflash

Library for parsing Intel UEFI images
