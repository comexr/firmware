# uefi_std

UEFI standard library
